=== Plugin Name ===
Contributors:360sht 
Donate link: http://vcode.360sht.com/
Tags: comments, spam
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

基于海量手写字符、复杂安全技术而生成的图片验证码，提高了破解难度。

== Description ==

火柴手写码，是将海量手写图片资源进行碎片化处理，随机组合、加密而成；由于源数据重复概率低、手写文字差异大（即使同一个人多次书写同一数字，其结果也不尽相同）、手写字符书写不规则等特点，使得现有OCR技术很难识别；同时我们结合大数据处理和云计算技术，为开发者提供清晰、安全、方便的云验证码服务。

== Installation ==

1. Upload all files to your Wordpress plugins directory, usually `wp-content/plugins/`.上传插件到插件目录
2. Activate the plugin through the 'Plugins' menu in WordPress.后台激活插件并配置参数
3. Done.

== Screenshots ==

1.vcode comments 火柴手写码界面

== Changelog ==
none

== Frequently Asked Questions ==
none

== Upgrade Notice ==
none

